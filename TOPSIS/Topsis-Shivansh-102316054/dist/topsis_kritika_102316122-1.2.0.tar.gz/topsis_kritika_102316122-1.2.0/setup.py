from setuptools import setup, find_packages

with open("README.md", "r") as fh:
    long_description = fh.read()

setup(
    name="Topsis-Kritika-102316122",
    version="1.2.0",
    author="Kritika Kandhari",
    author_email="kkandhari_be22@thapar.edu",
    description="A Python package for implementing TOPSIS",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    entry_points={
        'console_scripts': [
            'topsis=Topsis_Kritika_102316122.topsis:main',
        ],
    },
)
